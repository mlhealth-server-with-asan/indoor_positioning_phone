package com.example.wifi_positining;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.provider.Settings.Secure;


import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class ForegroundService extends Service {

    // Assuming these are member variables in your service
    private MqttAndroidClient mqttAndroidClient;
    private String serverURI = "tcp://192.168.94.153:8001"; // Replace with your actual server URI
    private String TAG = "ForegroundService";
    private String phoneNumber = getDeviceId(); // Replace with actual phone number or client id


    private String getDeviceId() {
        return Secure.getString(getContentResolver(), Secure.ANDROID_ID);
    }
    @Override
    public void onCreate() {
        super.onCreate();
        // Initialize your MQTT client here
        mqttAndroidClient = new MqttAndroidClient(getApplicationContext(), serverURI, phoneNumber);
        mqttAndroidClient.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.e(TAG, "connectComplete");
                subscribe();
            }

            @Override
            public void connectionLost(Throwable cause) {
                Log.e(TAG, "connectionLost", cause);
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.e(TAG, "messageArrived: " + new String(message.getPayload(), "UTF-8"));
                // Handle your message
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.e(TAG, "deliveryComplete");
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Connect and start service here if needed
        connect();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // We don't provide binding, so return null
        return null;
    }

    @Override
    public void onDestroy() {
        // Clean up and disconnect here
        disconnect();
        super.onDestroy();
    }

    public void connect() {
        try {
            IMqttToken token = mqttAndroidClient.connect(getMqttConnectionOption());
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncToken) {
                    // Connection successful
                    Log.e(TAG, "Connect success");
                }

                @Override
                public void onFailure(IMqttToken asyncToken, Throwable exception) {
                    // Connection failed
                    Log.e(TAG, "Connect fail", exception);
                }
            });
        } catch (MqttException e) {
            Log.e(TAG, "MqttException - " + e);
        }
    }

    public void disconnect() {
        if (mqttAndroidClient.isConnected()) {
            try {
                mqttAndroidClient.disconnect();
            } catch (MqttException e) {
                Log.e(TAG, "MqttException - " + e);
            }
        }
    }

    private void subscribe() {
        try {
            mqttAndroidClient.subscribe("your_topic", 2); // Replace with your actual topic
        } catch (MqttException e) {
            Log.e(TAG, "MqttException - " + e);
        }
    }

    private MqttConnectOptions getMqttConnectionOption() {
        // Implement this based on your screenshot
        MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
        mqttConnectOptions.setCleanSession(true);
        mqttConnectOptions.setAutomaticReconnect(true);
        mqttConnectOptions.setConnectionTimeout(60);
        mqttConnectOptions.setKeepAliveInterval(10);
        return mqttConnectOptions;
    }

    private DisconnectedBufferOptions getDisconnectedBufferOptions() {
        // Implement this based on your screenshot
        DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
        disconnectedBufferOptions.setBufferEnabled(true);
        disconnectedBufferOptions.setBufferSize(100);
        disconnectedBufferOptions.setPersistBuffer(true);
        disconnectedBufferOptions.setDeleteOldestMessages(false);
        return disconnectedBufferOptions;
    }
}
